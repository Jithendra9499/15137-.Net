﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EFAssignment.Models;


namespace EFAssignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
           
        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            TrainingContext db = new TrainingContext();
            string UserName = "admin";
            string Password = "123";
            Userdatum user = db.Userdata.SingleOrDefault(u => u.Username == UserName && u.Password == Password);
            if (txtUserName.Text == "admin" && txtPassword.Text == "123")
            {
                lblMessage.Text = "Valid User";
            }
            else
            {
                lblMessage.Text = "Invalid User Name or Password";
            }

        }
    }
}
