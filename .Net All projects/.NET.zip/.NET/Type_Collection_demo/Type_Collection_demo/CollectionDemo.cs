﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Type_Collection_demo
{
    class CollectionDemo
    {
        static void Main(string[] args)
        {
            /* int[] numberArray = new int[3];
             numberArray[0] = 435;
             numberArray[1] = 1234;
             numberArray[2] = 52;
             for (int i=0; i<numberArray.Length;i++)
             {
                 Console.WriteLine(numberArray[i]);
         }
            */
            #region System.Collection classes
            /*ArrayList countryList = new ArrayList();
            countryList.Add("India");
            countryList.Add("france");
            countryList.Insert(1, "USA");
            countryList.Add(100);
            countryList.Add(true);
            Person person = new Person { FirstName = "Jithendra", LastName = "Rajpurohit" };
            Console.WriteLine(person.FirstName + " " + person.LastName);
            Console.WriteLine("-------------------------------------\n");
            countryList.Add(person);
            Console.WriteLine(((Person)countryList[5]).FirstName);
            Console.WriteLine("-------------------------------------\n");
            for (int i = 0; i < countryList.Count; i++)
            {
                Console.WriteLine(countryList[i]);
            }
            */
            #endregion

            #region Generic Collection classes
            /* List<string> countryList = new List<string>();
             countryList.Add("India");
             List<int> Numbers = new List<int>();
             Numbers.Add(100);
             List<Person> PersonList = new List<Person>();
             PersonList.Add(new Person() { FirstName = "Jithendra", LastName = "Rajpurohit" });
             Console.WriteLine(PersonList[0].FirstName);
            */
            #endregion

            #region Nullable Type
            Nullable<int> x = null;
            x = 100;
            x = null;
            //dataype? ---------nullabletype
            int? y = null;
            #endregion
        }
    }
}
