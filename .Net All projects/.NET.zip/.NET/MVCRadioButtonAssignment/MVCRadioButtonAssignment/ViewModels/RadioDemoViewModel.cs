﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVCRadioButtonAssignment.ViewModels;
using MVCRadioButtonAssignment.Models;








namespace MVCRadioButtonAssignment.ViewModels
{
    public class RadioDemoViewModel
    {
        public string Country { get; set; }
        public List<string> CountryList { get; set; }
        public List<Employee> Employees { get; set; }
    }
}