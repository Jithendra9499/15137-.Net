﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MVCRadioButtonAssignment.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using MVCRadioButtonAssignment.ViewModels;



namespace MVCRadioButtonAssignment.Controllers
{
    public class HomeController : Controller
    {
        private NorthwindContext db;
        public HomeController(NorthwindContext context)
        {
            db = context;
        }

        public IActionResult Index()
        {
            var countries = db.Employees.Select(e => e.Country).Distinct().ToList();
            RadioDemoViewModel radioDemoViewModel = new RadioDemoViewModel();
            radioDemoViewModel.CountryList = countries as List<string>;
            radioDemoViewModel.CountryList.Insert(0, "All");
            radioDemoViewModel.Employees = new List<Employee>();
            string dataserializedata = JsonSerializer.Serialize(radioDemoViewModel);
            HttpContext.Session.SetString("dataobj", dataserializedata);
            return View(radioDemoViewModel);

        }
        [HttpPost]
        public IActionResult Index(RadioDemoViewModel viewModelObject)
        {
            string country = viewModelObject.Country;
            string data = HttpContext.Session.GetString("dataobj");
            RadioDemoViewModel radioDemoViewModel = JsonSerializer.Deserialize<RadioDemoViewModel>(data);
            viewModelObject.CountryList = radioDemoViewModel.CountryList;
            var employeedata = from e in db.Employees select e;
            if(country!="All")
            {
                employeedata = employeedata.Where(e => e.Country.ToUpper() == country.ToUpper());
            }
            radioDemoViewModel.Employees = employeedata.ToList();
            return View(radioDemoViewModel);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
