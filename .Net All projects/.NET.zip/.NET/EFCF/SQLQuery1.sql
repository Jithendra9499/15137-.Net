﻿select * from [dbo].[__EFMigrationsHistory]
select * from [dbo].[Category]
select * from [dbo].[Product]

sp_help 'product'
