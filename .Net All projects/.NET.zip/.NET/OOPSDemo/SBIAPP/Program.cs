﻿using System;
using BankLibrary;

namespace SBIAPP
{
    class Program
    {
        static void Main(string[] args)

        {
            /* Bank bank = new Bank();
            bank.AccHolderName = "Jithendra";
            //bank.Balance = 2000;

             Console.WriteLine(bank);

             bank.Deposit(5000);
            Console.WriteLine(bank.ToString());

             bank.Withdraw(3000);
            Console.WriteLine(bank);

             Console.WriteLine("------------");

             Bank bank1 = new Bank("Amit", 7000);
            Console.WriteLine(bank1);

             object obj = new object();
            Console.WriteLine(obj.ToString());
            */



            Savings savings = new Savings("jithendra", 4000);
            Console.WriteLine(savings);
            Console.WriteLine("Interest Amount=" + savings.CalculateInterest());

           /* try
            {
                savings.Withdraw(10000);
            }
            catch (BalanceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine(savings);
           */
        }
    }
}