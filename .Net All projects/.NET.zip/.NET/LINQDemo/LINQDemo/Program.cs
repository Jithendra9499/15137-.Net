﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LINQDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Array
            int[] numbers = { 44, 566, 34, 567, 890, 123 };
            int[] evendata = (from n in numbers where n % 2 == 0 select n).ToArray();
            evendata = numbers.Where(n => n % 2 == 0).ToArray();
           
            for (int  i=0; i<evendata.Length;i++)
            {
                Console.WriteLine(evendata[i]);
            }
            #endregion

            #region List
            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee() { EmpNo = 101, EmpName = "bhavana", Address = "mumbai", Dept = "hr", Salary = 15000 });
            empList.Add(new Employee() { EmpNo = 102, EmpName = "amit", Address = "mumbai", Dept = "sales", Salary = 25000 });
            empList.Add(new Employee() { EmpNo = 103, EmpName = "vishal", Address = "pune", Dept = "sales", Salary = 20000 });
            empList.Add(new Employee() { EmpNo = 104, EmpName = "priya", Address = "mumbai", Dept = "hr", Salary = 30000 });
            empList.Add(new Employee() { EmpNo = 105, EmpName = "asha", Address = "mumbai", Dept = "sales", Salary = 30000 });
            empList.Add(new Employee() { EmpNo = 106, EmpName = "pankaj", Address = "pune", Dept = "hr", Salary = 35000 });
            empList.Add(new Employee() { EmpNo = 107, EmpName = "anil", Address = "mumbai", Dept = "sales", Salary = 18000 });
            empList.Add(new Employee() { EmpNo = 108, EmpName = "preeti", Address = "pune", Dept = "hr", Salary = 25000 });
            #endregion

            IEnumerable<Employee> query1 = from e in empList select e;
            IEnumerable<Employee> query2 = from e in empList where  e.Dept == "sales" select e;
            query2 = empList.Where(e => e.Dept == "sales");

            IEnumerable<Employee> query3 = from e in empList where e.Salary > 25000 select e;
            query3 = empList.Where(e => e.Salary > 25000);
            IEnumerable<Employee>query4 = from e in empList where e.Address == "mumbai" && e.Dept=="hr" select e;
            query4 = empList.Where(e => e.Address == "mumbai" && e.Dept == "hr");
            IEnumerable<Employee> query5 = from e in empList where e.EmpName.StartsWith('p') select e;
            //defered execution
            query5 = empList.Where(e => e.EmpName.StartsWith('p'));
            //immediate execution
            query5 = empList.Where(e => e.EmpName.StartsWith("p")).ToList();
            empList.Add(new Employee() { EmpNo = 201, EmpName = "peter", Address = "pune", Dept = "hr", Salary = 25000 });
            Console.WriteLine("-------------------Line query output--------------");
            /*foreach (Employee item in query5)
            {
                Console.WriteLine(item);
            }*/
             //empList.Add(new Employee() { EmpNo = 301, EmpName = "peter1", Address = "pune", Dept = "hr", Salary = 25000 });
            //Console.WriteLine("-------------------Line query output--------------");
            // //defered execution
            // /*foreach (Employee item in query5)
            //{
            //    Console.WriteLine(item);
            //}*/
            //Employee emp = (from e in empList where e.EmpNo == 1022 select e).SingleOrDefault();

            // Employee emp = (from e in empList where e.Address == "mumbai" select e).FirstOrDefault();
             //emp = empList.Where(e => e.EmpNo == 102).FirstOrDefault();
             //emp = empList.FirstOrDefault(e => e.EmpNo == 102);
             //Console.WriteLine("Employee:" +emp);

            IEnumerable<Employee> query7 = from e in empList select e;
            //known type
            //Employee
            //annonymous type--new{}



            var query8 = from e in empList select new { e.EmpName, e.Dept, e.Salary };
            query8 = empList.Select(e => new { e.EmpName, e.Dept, e.Salary });
            var query9 = from e in empList where e.Salary > 20000 && e.Salary < 30000 select new { e.EmpName, e.Salary };



            foreach (var item in query9)
            {
                // Console.WriteLine(item.EmpName + " " + item.Dept + " " + item.Salary);
                Console.WriteLine(item.GetType().Name);
            }

        }
    }
}
