﻿using System;

namespace DataLibrary
{
    public class Emp
    {
        public int EmpNo { get; set; }
        public string EmpName { get; set; }
        public DateTime? HireDate { get; set; }
        public Decimal? Salary { get; set; }
    }
}
