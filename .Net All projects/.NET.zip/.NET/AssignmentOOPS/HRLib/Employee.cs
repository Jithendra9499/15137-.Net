﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRLib
{
   public class Employee
    {
        #region Fields and Properties
        private string empName;
        public string EmpName
        {
            get { return empName; }
            set { empName = value; }
        }
        private string address;
        public string Address
        {
            get { return address; }
            protected set { address = value; }
        }
        #endregion
        #region Constructor
        public Employee ()
        {
            empName = "jithendra";
            address = "AP";

        }
        public Employee(string name, string add)
        {
            this.EmpName = name;
            this.Address = add;
        }
        #endregion
        public override string ToString()
        {
            return string.Format($"Employee Name:{EmpName}  Address:{Address}");
        }
    }
}
