﻿using System;


namespace HRLib
{
    class Program
    {
        static void Main(string[] args)
        {
           // Employee employee = new Employee("Kumar", "AP");
            //Console.WriteLine(employee.ToString());
        }
    }
}
