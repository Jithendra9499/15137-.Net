﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace MVCDemoApp.Models
{
    public class EmpMetaData
    {
        [BindRequired, Required]
        public int EmpNo { get; set; }

        [Required(ErrorMessage="EmpName is required")]
        public string Ename { get; set; }
    }
}
