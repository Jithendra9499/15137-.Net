﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace MVCDemoApp.Models
{
    public class Employee
    {
        [Required(ErrorMessage ="EmpId is compulsory Field")]
        [RegularExpression(@"[0-9]{4}",ErrorMessage ="Enter Four Digit EmpId")]
        public int? EmpId { get; set; }

        [Required(ErrorMessage = "EmpName is compulsory Field")]
        [StringLength(10, ErrorMessage = "Enter Four Digit EmpId")]
        public string EmpName { get; set; }

        [Required(ErrorMessage = "Salary is compulsory Field")]
        public double? Salary { get; set; }
    }
}
