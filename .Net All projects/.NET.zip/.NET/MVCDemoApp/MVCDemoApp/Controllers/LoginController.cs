﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVCDemoApp.Models;
using Microsoft.Extensions.Configuration;

namespace MVCDemoApp.Controllers
{
    public class LoginController : Controller
    {
        TrainingContext db;
        public LoginController(TrainingContext context)
        {
            db = context;
        }
        [HttpGet]
        public IActionResult Index()
        {
           
            return View(new Userdatum());
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(Userdatum user)
        {
            Userdatum obj = db.Userdata.SingleOrDefault(u => u.Username == user.Username && u.Password == user.Password);
                if(obj!=null)
            {
                return RedirectToAction("Index", "Emp");
            }
                else
            {
                ModelState.AddModelError("error", "User name or Password invalid");
            }
            return View(user);
            

            
           
        }

       
    }
}
