﻿using System;
namespace demoApp1
{
    public class Program
    {
        public static void Main(string[] args)
        {

            int number;
            Console.WriteLine("Enter a number to check : ");
            number = int.Parse(Console.ReadLine());
            Console.WriteLine(OddEvenCheck(number));
        }

        public static string OddEvenCheck(int number)
        {
            if (number % 2 == 0)
            {
                return number + " is an even number";
            }
            else
            {
                return number + " is an odd number";
            }
        }
    }
}