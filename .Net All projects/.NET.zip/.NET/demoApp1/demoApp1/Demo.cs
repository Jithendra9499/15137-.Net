﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demoApp1
{
    class Demo
    {
        static void Main(string[] args)
        {
            Rectangle rectangle = new Rectangle();
            rectangle.Length = 20;
            rectangle.Width = 40;
            Console.WriteLine("Area = " + GetRectangleArea());
        }
    }
}
