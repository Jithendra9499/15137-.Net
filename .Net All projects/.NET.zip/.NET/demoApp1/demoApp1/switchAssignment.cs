﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demoApp1
{
    class switchAssignment
    {
        static void Main(string[] args)
        {

			int monno;

			Console.WriteLine("Enter Month No : ");
			monno = Convert.ToInt32(Console.ReadLine());

			switch (monno)
			{
				case 1:
				case 2:
				case 11:
				case 12:
					Console.WriteLine("winter");
					break;
				case 3:
					
				case 4:
					
				case 5:
				case 10:
					
					Console.WriteLine("summer");
					break;
				case 6:
					
				case 7:
					
				case 8:
					
				case 9:
					
					Console.WriteLine("monsoon");
					break;
				
				
				default:
					Console.Write("invalid Month number Please try again ....\n");
					break;
			}
		}
    }
}
